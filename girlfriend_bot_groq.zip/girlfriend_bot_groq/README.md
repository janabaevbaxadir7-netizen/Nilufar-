# 💬 Girlfriend Bot — O'rnatish Qo'llanmasi

## Tuzilma
```
bot/
├── main.py           — Bot ishga tushirish
├── config.py         — Sozlamalar
├── database.py       — SQLite (ma'lumotlar bazasi)
├── requirements.txt  — Kutubxonalar
├── railway.toml      — Railway config
├── .env.example      — Environment variables namunasi
├── ai/
│   └── girlfriend.py — AI qiz logikasi (Nilufar)
└── handlers/
    ├── user.py       — Foydalanuvchi handlerlari
    └── admin.py      — Admin panel
```

---

## 1. Bot yaratish (@BotFather)

1. Telegramda `@BotFather` ga yozing
2. `/newbot` buyrug'ini yuboring
3. Bot nomini kiriting (masalan: `Nilufar Bot`)
4. Username kiriting (masalan: `nilufar_ai_bot`)
5. `BOT_TOKEN` ni oling va saqlang

---

## 2. Anthropic API Key olish

1. https://console.anthropic.com ga kiring
2. `API Keys` bo'limiga o'ting
3. `Create Key` bosing
4. `ANTHROPIC_API_KEY` ni saqlang

---

## 3. Admin ID ni bilish

Telegramda `@userinfobot` ga `/start` yozing — u sizning ID ingizni ko'rsatadi.

---

## 4. Railway deploy

1. https://railway.app ga kiring
2. GitHub bilan ulaning
3. `New Project` → `Deploy from GitHub repo`
4. Bu papkani GitHub ga yuklang
5. Railway'da `Variables` bo'limiga o'ting:
   - `BOT_TOKEN` = sizning bot tokeningiz
   - `ANTHROPIC_API_KEY` = sizning API keyingiz
   - `ADMIN_IDS` = sizning Telegram ID ingiz

6. Deploy avtomatik boshlanadi!

---

## Buyruqlar

### Foydalanuvchi:
- `/start` — botni boshlash
- `/vip` — VIP ma'lumoti
- `/me` — mening profilim
- `/reset` — suhbatni tozalash

### Admin:
- `/admin` — admin panel (faqat adminlarga ko'rinadi)

---

## Admin Panel imkoniyatlari

| Bo'lim | Imkoniyat |
|--------|-----------|
| 📊 Statistika | Foydalanuvchilar soni, VIP, xabarlar |
| 👑 VIP | Qo'shish, olib tashlash, ro'yxat |
| 👥 Foydalanuvchilar | Ro'yxat, blok qo'yish |
| 💬 Shaxsan chat | Nilufar sifatida foydalanuvchi bilan gaplashish |
| 📢 Broadcast | Hammaga xabar yuborish |
| ⚙️ Sozlamalar | VIP narxini o'zgartirish |

---

## VIP jarayoni

```
Foydalanuvchi → /vip → "VIP olish" tugmasi
    ↓
Admin(lar)ga bildirishnoma keladi
    ↓
Admin foydalanuvchi bilan to'lovni kelishadi
    ↓
Admin "✅ VIP berdim" bosadi
    ↓
Foydalanuvchiga VIP 7 kunlik avtomatik beriladi
```

---

## Xarajat hisob-kitobi (taxminiy)

- Railway hobby plan: ~$5/oy
- Claude Haiku API: ~$0.25/million token
  - Kuniga 1000 xabar ≈ ~$0.05/kun ≈ ~$1.5/oy
- **Jami: ~$6-7/oy** (0.5GB RAM da yaxshi ishlaydi)
